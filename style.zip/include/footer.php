<footer>

<div class="container-fluid">

<div class="col-sm-12">
<p id="copyright">Copyright 2021</p>
</div>
</div>
</footer>
</body>
</html>