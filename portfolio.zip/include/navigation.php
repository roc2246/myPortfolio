
  <nav>
  <a href="index.php">Home</a><br>
  <a href="aboutme.php">About Me</a><br>
  <a href="projects.php">Projects</a><br>
  <a href="experience.php">Work Experience</a><br>
  <a href="contact.php">Contact Information</a><br>
  </nav>

