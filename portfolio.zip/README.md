# myPortfolio

This is the first web peortfolio I'm creating to show my current and future work. Any 
constructive feedback and changes are welcome.
